package guanLiXiTong;

import java.util.Scanner;

public class xiTong {
    static int shuiLv = 3000;
    public static void main(String args[]){
        System.out.println("欢迎进入博士研究生管理系统");
        System.out.println("目前博士研究生有:");
        System.out.println("张三，男，28岁，所交学费（年）:无，所得薪水（年）:无，年应缴纳金额:无");
        System.out.println("李四，女，27岁，所交学费（年）:无，所得薪水（年）:无，年应缴纳金额:无");
        int i = 0,j = 0;
            retry:
            for(i=0;i<1;i++){
                try{
                    System.out.print("请输入张三所交学费（年）:");
                    Scanner  sj= new Scanner(System.in);
                    xueShengJieKou xsjk;
                    xsjk = new zhangSan();
                    int XF = sj.nextInt();
                    if(XF <= 0||XF>1000000){
                        System.out.println("请输入正整数并且数值不能超过1000000");
                        i = 0;
                        break retry;
                    }
                    System.out.print("请输入李四所交学费（年）:");
                    Scanner  sj2= new Scanner(System.in);
                    xueShengJieKou xsjk2;
                    xsjk2 = new liSi();
                    int XF2 = sj2.nextInt();
                    if(XF2 <= 0||XF2>1000000){
                        System.out.println("请输入正整数并且数值不能超过1000000");
                        i = 0;
                        break retry;
                    }

                    System.out.print("请输入张三所得薪水（年）:");
                    Scanner  sd= new Scanner(System.in);
                    jiaoShiJieKou sdxs;
                    sdxs = new zhangSan();
                    int XS = sd.nextInt();
                    if(XS <= 0||XS>1000000){
                        System.out.println("请输入正整数并且数值不能超过1000000");
                        i = 0;
                        break retry;
                    }

                    System.out.print("请输入李四所得薪水（年）:");
                    Scanner  sd2= new Scanner(System.in);
                    jiaoShiJieKou sdxs2;
                    sdxs2 = new zhangSan();
                    int XS2 = sd2.nextInt();
                    if(XS2 <= 0||XS2>1000000){
                        System.out.println("请输入正整数并且数值不能超过1000000");
                        i = 0;
                        break retry;
                    }

                    int SHJE = XS - XF;
                    int SHJE2 = XS2 - XF2;
                    int JNJE = 0;
                    int JNJE2 = 0;

                    System.out.print("张三，男，28岁，所交学费（年）:");
                    xsjk.jiaoNaXueFei(XF);
                    System.out.print("，所得薪水（年）:");
                    sdxs.faFangXinShui(XS);
                    System.out.print("，年应缴纳金额:");
                    if(SHJE<=shuiLv){
                        System.out.println(JNJE);
                    }else if(SHJE>shuiLv) {
                        JNJE = SHJE/10-210;
                        System.out.println(JNJE);
                    }

                    System.out.print("李四，女，27岁，所交学费（年）:");
                    xsjk.jiaoNaXueFei(XF2);
                    System.out.print("，所得薪水（年）:");
                    sdxs.faFangXinShui(XS2);
                    System.out.print("，年应缴纳金额:");
                    if(SHJE2<=shuiLv){
                        System.out.println(JNJE2);
                    }else if(SHJE2>shuiLv) {
                        JNJE2 = SHJE2/10-210;
                        System.out.println(JNJE2);
                    }
                    j = 1;
                }
                catch(Exception e){
                    System.out.print("发生错误:");
                    System.out.println(e.getMessage());
                    System.out.println("请输入正整数，谢谢配合");
                    i = 0;
                    break retry;
                }
            }
        }
    }