package guanLiXiTong;

public interface xueShengJieKou {
    void jiaoNaXueFei(int xf); //缴纳学费
}